# residentialapp
Aplicación para propiedad horizontal.
